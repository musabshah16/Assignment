using System;
namespace EmployeeProject{

    class Employee{
    public int EmployeeId{ get; set;}
    public string FirstName { get; set;}
    public string LastName{get; set;}
    public string Title{get; set;}
    public DateOnly DOB{get; set;}
    public DateOnly DOJ {get; set;}
    public string City{get; set;}
    }
}