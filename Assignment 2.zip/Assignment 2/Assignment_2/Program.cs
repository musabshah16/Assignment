﻿using Assignment_2;
using System;
using static System.Reflection.Metadata.BlobBuilder;

namespace Assignment_1
{
    public class main
    {
        static void Main(string[] args)
        {
            Employee emp = new Employee();
            emp.EmployeeDetails();
            Console.ReadKey();

        }
    }
}