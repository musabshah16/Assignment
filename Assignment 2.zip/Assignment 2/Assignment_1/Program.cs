﻿using System;

namespace Assignment_1
{
    public class main
    {
        static void Main(string[] args)
        {

            /*Calculator calculator = new Calculator();
            calculator.Console_Calculator();*/

            /*      AverageMarks av = new AverageMarks();
                  av.AvgMarks();*/

           /* Console.WriteLine("Sum of the array is {0}", StaticArray.Method(new int[] { 1, 3, 5, 7, 9 }));*/

            /* SwapNumbers swapNumbers = new SwapNumbers();
            swapNumbers.SwapNumber();*/

          /*  Circle circle = new Circle();
            circle.Circumfernce();*/

           Books d = new Books();
            d.Method();
          
        }
    }
}